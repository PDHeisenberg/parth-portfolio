(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))p(t);new MutationObserver(t=>{for(const n of t)if(n.type==="childList")for(const l of n.addedNodes)l.tagName==="LINK"&&l.rel==="modulepreload"&&p(l)}).observe(document,{childList:!0,subtree:!0});function s(t){const n={};return t.integrity&&(n.integrity=t.integrity),t.referrerPolicy&&(n.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?n.credentials="include":t.crossOrigin==="anonymous"?n.credentials="omit":n.credentials="same-origin",n}function p(t){if(t.ep)return;t.ep=!0;const n=s(t);fetch(t.href,n)}})();const a={name:"Parth Dhawan",tagline:"Designer based in Singapore 🇸🇬, driven by curiosity and a knack for building cool stuff. Designing isn't just my job—it's a lens through which I view everything.",resumeUrl:"https://drive.google.com/file/d/1AeOOZF99hU5Jc9nHtGxep4Mas_K_Ca41/view?usp=share_link"},f=[{title:"Team Lead",company:"Grab",period:"2024 - Present"},{title:"Lead Designer",company:"Grab",period:"2022 - 2024"},{title:"Senior Designer",company:"Agoda",period:"2019 - 2022"},{title:"Product Designer",company:"Flipkart",period:"2016 – 2019"},{title:"UX/UI Designer",company:"PepperTap",period:"2015 – 2016"}],o=[{id:"offerandmore",title:"Offers & More",company:"Grab",description:"A dedicated landing page for all offers, budget meals, free delivery and more.",thumbnail:"/assets/images/offers-thumbnail.png",slug:"/work/offerandmore",fullPresentationSlug:"/work/offers-and-more-details",role:"Lead Product Designer",year:"2024",context:"After the pandemic, as inflation rose, consumers in SEA prioritized affordability. Our NPS surveys consistently showed that despite our competitive pricing, GrabFood was perceived as 'not affordable.' This project was the first major step our team took toward making Grab more affordable by creating a solution that addresses various user intents and helps them find the right restaurant.",insights:{eater:["Promos are not visible and accessible.","Lowest promo discoverability compared to competitors.",'The definition of "affordability" varies based on age, income and culture.'],merchant:["The promotions are barely affecting sales.","As a result, fewer merchants are inclined to offer discounts.","Merchants providing higher discounts don't receive special placement."]},launch:{description:"By Q2 2024, we launched our first experiment of the new affordability-focused landing page with features like visual filters and the new Merchant listing. We observed the following results:",results:["Tile CTR: 12.3%","The majority of sessions (58%) involved clicking into a merchant, with ~15% of these clickthrough sessions leading to conversion.","Both savings-conscious and price-conscious users showed higher conversion rates.","Visual filters were selected 31.12% of the time."]}},{id:"grouporders",title:"Group Orders Tiered Promos",company:"Grab",description:"A new, convenient way for big groups to order together and unlock bigger savings.",thumbnail:"/assets/images/grouporders-thumbnail.png",slug:"/work/grouporders",fullPresentationSlug:"/work/group-orders-tiered-promos",role:"Lead Product Designer",year:"2024",background:"Our affordability team was working on a project called Group Orders to make it easier for large groups to order food together and save money. During a critical development phase, the lead designer had to go on maternity leave. Recognising the project's extensive cross-functional dependencies and its impact, the team turned to me to steer this towards the finish line.",problem:["One person has to take all the ownership.","Pass their phone.","Ask everyone for their preference.","Pay for everyone and split the bill afterwards."],solution:["No more phone passing.","No need to chase.","Include automatic bill-splitting."],results:{conversionRate:"~35%",orderPercentage:"1%",marginComparison:"6.4% vs 10.8%"}},{id:"trip-planning",title:"Cart & Trip Planning",company:"Agoda",description:"Building a one-stop-shop trip planning and booking experience on Agoda",thumbnail:"/assets/images/tripplanning-thumbnail.png",slug:"/work/trip-planning",fullPresentationSlug:"/Cart",role:"Senior Product Designer",year:"2021",overview:"Agoda is a Southeast Asian online travel marketplace owned by the Booking Holdings group. As of June 2021, Agoda lists 2.5 million properties worldwide. After 15 years of listing and selling hotels, the company expanded into other areas, such as flights, vacation rentals, and activities.",businessReasons:["Retain customers by providing everything on a single platform","Allow for more significant discounts for repeat customers","Offer pre-made travel packages"],approach:"I favored the second approach (research-led, long-term vision) for the reasons: As Agoda has majorly been a hotel listing platform, we never really researched how people plan their overall trip. Not forming any long-term vision can lead to unanticipated scalability problems.",learnings:["Taking a long-term perspective really helped in aligning all stakeholders on a common direction.","Research was extremely helpful in understanding the travelers' pain points.","Moving quickly and involving developers early in the design process allowed us to gain early insights."]}],h=[{title:"Mobile/Web Designs",description:"Crafting intuitive and engaging designs for both mobile and web platforms."},{title:"Design Consultation",description:"Providing expert advice to enhance your product's design and user experience."},{title:"Mentorship",description:"Guiding aspiring designers to develop their skills and reach their full potential."}],v=[{platform:"twitter",handle:"@wwheisenbergeth",url:"https://x.com/wwheisenbergeth",icon:"twitter"},{platform:"instagram",handle:"@parth_dhawan",url:"https://www.instagram.com/parth_dhawan/",icon:"instagram"},{platform:"email",handle:"parthdhawan28",url:"mailto:parthdhawan28@gmail.com",icon:"email"}],w=[{title:"Talk to my AI assistant",url:"/chat",icon:"ai"},{title:"FREE | Icon set",url:"https://www.figma.com/community/file/1275092859040896934/free-editable-icon-set-with-animations",icon:"figma"}],u={url:"/Readinglist",featuredBook:{title:"The Fabric of Reality"}},r={linkedin:()=>`
    <svg viewBox="0 0 24 24" fill="#0A66C2">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
    </svg>
  `,twitter:()=>`
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
    </svg>
  `,instagram:()=>`
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
    </svg>
  `,email:()=>`
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
      <polyline points="22,6 12,13 2,6"/>
    </svg>
  `,ai:()=>`
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="10"/>
      <path d="M12 16v-4"/>
      <path d="M12 8h.01"/>
    </svg>
  `,figma:()=>`
    <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M15.852 8.981h-4.588V0h4.588c2.476 0 4.49 2.014 4.49 4.49s-2.014 4.491-4.49 4.491zM12.735 7.51h3.117c1.665 0 3.019-1.355 3.019-3.019s-1.355-3.019-3.019-3.019h-3.117V7.51zM8.148 24c-2.476 0-4.49-2.014-4.49-4.49s2.014-4.49 4.49-4.49h4.588v4.49c0 2.476-2.013 4.49-4.588 4.49zm-.001-7.509c-1.665 0-3.019 1.355-3.019 3.019s1.355 3.019 3.019 3.019 3.019-1.355 3.019-3.019v-3.019H8.147zM8.148 8.981c-2.476 0-4.49-2.014-4.49-4.49S5.672 0 8.148 0h4.588v8.981H8.148zm-.001-7.51c-1.665 0-3.019 1.355-3.019 3.019s1.355 3.019 3.019 3.019h3.117V1.471H8.147zM8.148 15.02c-2.476 0-4.49-2.014-4.49-4.49s2.014-4.49 4.49-4.49h4.588v8.98H8.148zm-.001-7.509c-1.665 0-3.019 1.355-3.019 3.019s1.355 3.019 3.019 3.019h3.117V7.511H8.147zM15.852 15.02c-2.476 0-4.49-2.014-4.49-4.49s2.014-4.49 4.49-4.49 4.49 2.014 4.49 4.49-2.014 4.49-4.49 4.49zm0-7.509c-1.665 0-3.019 1.355-3.019 3.019s1.355 3.019 3.019 3.019 3.019-1.355 3.019-3.019-1.354-3.019-3.019-3.019z"/>
    </svg>
  `,arrow:()=>`
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <line x1="7" y1="17" x2="17" y2="7"/>
      <polyline points="7 7 17 7 17 17"/>
    </svg>
  `,arrowLeft:()=>`
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <line x1="19" y1="12" x2="5" y2="12"/>
      <polyline points="12 19 5 12 12 5"/>
    </svg>
  `};function y(){return`
    <h1 class="name">${a.name}</h1>
    
    <div class="bento-grid">
      <!-- About Card -->
      <div class="card about-card">
        <span class="section-label">About</span>
        <p>${a.tagline}</p>
      </div>
      
      <!-- Profile Photo Card -->
      <div class="card profile-card">
        <a href="/chat" class="ai-button">
          <span>Chat with my</span>
          <strong>AI Assistant</strong>
        </a>
        <div class="profile-photo-wrapper">
          <img src="/src/assets/images/rotating-badge.png" class="rotating-text" alt="">
          <img src="/src/assets/images/profile.png" class="profile-photo" alt="${a.name}">
        </div>
      </div>
      
      <!-- Case Study 1: Offers & More -->
      ${c(o[0])}
      
      <!-- LinkedIn Card -->
      <a href="https://www.linkedin.com/in/parthdhawan/" target="_blank" rel="noopener" class="card linkedin-card">
        ${r.linkedin()}
        <span class="arrow">${r.arrow()}</span>
      </a>
      
      <!-- Experience Card -->
      <div class="card experience-card">
        <span class="section-label">Experience</span>
        <ul class="experience-list">
          ${f.map(i=>`
            <li class="experience-item">
              <div>
                <h4>${i.title}</h4>
                <span class="company">${i.company}</span>
              </div>
              <span class="period">${i.period}</span>
            </li>
          `).join("")}
        </ul>
        <a href="${a.resumeUrl}" target="_blank" rel="noopener" class="resume-link">
          View resume ${r.arrow()}
        </a>
      </div>
      
      <!-- Services Card -->
      <div class="card services-card">
        <span class="section-label">Services</span>
        <div class="services-carousel">
          ${h.map(i=>`
            <div class="service-item">
              <h3>${i.title}</h3>
              <p>${i.description}</p>
            </div>
          `).join("")}
          <!-- Duplicate for infinite scroll effect -->
          ${h.map(i=>`
            <div class="service-item">
              <h3>${i.title}</h3>
              <p>${i.description}</p>
            </div>
          `).join("")}
        </div>
      </div>
      
      <!-- Case Study 2: Group Orders -->
      ${c(o[1])}
      
      <!-- Reading List Card -->
      <a href="${u.url}" class="card reading-card">
        <div>
          <span class="section-label">Reading list</span>
        </div>
        <img src="/src/assets/images/book-cover.png" class="book-cover" alt="${u.featuredBook.title}">
      </a>
      
      <!-- Case Study 3: Cart & Trip Planning -->
      ${c(o[2])}
      
      <!-- Social Links -->
      <div class="card card--span-2">
        <div class="social-grid">
          ${v.map(i=>`
            <a href="${i.url}" target="_blank" rel="noopener" class="card social-card">
              ${r[i.icon]()}
              <h5>${i.handle}</h5>
            </a>
          `).join("")}
          ${w.map(i=>`
            <a href="${i.url.startsWith("http"),i.url}" ${i.url.startsWith("http")?'target="_blank" rel="noopener"':""} class="card social-card">
              ${r[i.icon]?r[i.icon]():""}
              <h5>${i.title}</h5>
            </a>
          `).join("")}
        </div>
      </div>
    </div>
    
    <footer class="footer">
      <p>Built with ⚡ by Parth Dhawan</p>
    </footer>
  `}function c(i){const e=i.id==="offerandmore"?"/src/assets/images/offers-mockup.png":i.id==="grouporders"?"/src/assets/images/grouporders-mockup.png":"/src/assets/images/tripplanning-mockup.png";return`
    <a href="${i.slug}" class="card case-study-card">
      <div class="card-content">
        <span class="section-label">Case Study</span>
        <h3>${i.title}</h3>
        <span class="company">${i.company}</span>
      </div>
      <div class="mockup">
        <img src="${e}" alt="${i.title} mockup">
      </div>
    </a>
  `}function b(i){const e=o.find(s=>s.slug.includes(i)||s.id===i);return e?`
    <div class="case-study-page">
      <a href="/" class="back-button">
        ${r.arrowLeft()} Back
      </a>
      
      <header class="case-study-header">
        <h1>${e.title}</h1>
        <p class="description">${e.description}</p>
        
        <div class="case-study-meta">
          <div class="case-study-meta-item">
            <h4>Role</h4>
            <p>${e.role}</p>
          </div>
          <div class="case-study-meta-item">
            <h4>Company</h4>
            <p>${e.company}</p>
          </div>
          <div class="case-study-meta-item">
            <h4>Year</h4>
            <p>${e.year}</p>
          </div>
          <a href="${e.fullPresentationSlug}" class="presentation-link">
            Full Presentation ${r.arrow()}
          </a>
        </div>
      </header>
      
      ${e.context?`
        <section class="case-study-section">
          <h2>Context</h2>
          <p>${e.context}</p>
        </section>
      `:""}
      
      ${e.background?`
        <section class="case-study-section">
          <h2>Background</h2>
          <p>${e.background}</p>
        </section>
      `:""}
      
      ${e.overview?`
        <section class="case-study-section">
          <h2>Overview</h2>
          <p>${e.overview}</p>
        </section>
      `:""}
      
      ${e.insights?`
        <section class="case-study-section">
          <h2>Insights</h2>
          <p><em>Based on our diary study research, Food Brandhealth, and NPS.</em></p>
          <h3>As an eater:</h3>
          <ul>
            ${e.insights.eater.map(s=>`<li>${s}</li>`).join("")}
          </ul>
          <h3>As a Merchant:</h3>
          <ul>
            ${e.insights.merchant.map(s=>`<li>${s}</li>`).join("")}
          </ul>
        </section>
      `:""}
      
      ${e.problem?`
        <section class="case-study-section">
          <h2>The Problem</h2>
          <p>Food ordering in big groups is Hard!</p>
          <ul>
            ${e.problem.map(s=>`<li>${s}</li>`).join("")}
          </ul>
        </section>
      `:""}
      
      ${e.solution?`
        <section class="case-study-section">
          <h2>Introducing ${e.title}</h2>
          <p>${e.description}</p>
          <ul>
            ${e.solution.map(s=>`<li>${s}</li>`).join("")}
          </ul>
        </section>
      `:""}
      
      ${e.businessReasons?`
        <section class="case-study-section">
          <h2>The Business of Travel</h2>
          <ul>
            ${e.businessReasons.map(s=>`<li>${s}</li>`).join("")}
          </ul>
        </section>
      `:""}
      
      ${e.launch?`
        <section class="case-study-section">
          <h2>Launch</h2>
          <p>${e.launch.description}</p>
          <ul>
            ${e.launch.results.map(s=>`<li>${s}</li>`).join("")}
          </ul>
        </section>
      `:""}
      
      ${e.results?`
        <section class="case-study-section">
          <h2>Results</h2>
          <ul>
            <li>Conversion Rate: ${e.results.conversionRate}</li>
            <li>Order Percentage: ${e.results.orderPercentage} of orders</li>
            <li>Margin: ${e.results.marginComparison}</li>
          </ul>
        </section>
      `:""}
      
      ${e.learnings?`
        <section class="case-study-section">
          <h2>Learnings</h2>
          <ul>
            ${e.learnings.map(s=>`<li>${s}</li>`).join("")}
          </ul>
        </section>
      `:""}
      
      <a href="/" class="back-button">
        ${r.arrowLeft()} Back to Home
      </a>
    </div>
  `:$()}function $(){return`
    <div class="case-study-page" style="text-align: center; padding: 4rem;">
      <h1 style="font-size: 6rem; margin-bottom: 1rem;">404</h1>
      <p style="font-size: 1.25rem; margin-bottom: 2rem;">It seems like this page doesn't exist, or it's gone.</p>
      <p>But don't worry! I'll get you back on track :)</p>
      <a href="/" class="back-button" style="margin-top: 2rem; display: inline-flex;">
        ${r.arrowLeft()} Back home
      </a>
    </div>
  `}function k(){window.addEventListener("popstate",()=>{window.handleRoute()}),document.addEventListener("click",i=>{const e=i.target.closest("a");if(e&&e.href&&!e.href.startsWith("http")&&!e.href.startsWith("mailto:")){const s=new URL(e.href);s.origin===window.location.origin&&(i.preventDefault(),window.navigateTo(s.pathname))}})}function g(){k(),d()}function d(){const i=window.location.pathname,e=document.getElementById("app");if(i==="/"||i==="/index.html")e.innerHTML=y(),C();else if(i.startsWith("/work/")){const s=i.replace("/work/","");e.innerHTML=b(s)}else i==="/Readinglist"?e.innerHTML=renderReadingListPage():i==="/chat"?e.innerHTML=renderChatPage():e.innerHTML=render404Page()}function C(){document.querySelectorAll(".case-study-card").forEach(i=>{i.addEventListener("click",e=>{const s=i.getAttribute("href");s&&!s.startsWith("http")&&(e.preventDefault(),m(s))})})}function m(i){window.history.pushState({},"",i),d(),window.scrollTo(0,0)}window.navigateTo=m;window.handleRoute=d;document.readyState==="loading"?document.addEventListener("DOMContentLoaded",g):g();
